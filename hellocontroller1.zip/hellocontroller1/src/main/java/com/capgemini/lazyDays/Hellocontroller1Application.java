package com.capgemini.lazyDays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hellocontroller1Application {

	public static void main(String[] args) {
		SpringApplication.run(Hellocontroller1Application.class, args);
	}
}
