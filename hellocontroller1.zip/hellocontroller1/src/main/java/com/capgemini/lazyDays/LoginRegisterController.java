package com.capgemini.lazyDays;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController

	public class LoginRegisterController 
	{
	@Autowired
	private UserService userRepo;
	
	@GetMapping("/{password}")
	
		public String get(@PathVariable("password") String password)
		{
			return userRepo.findByPassword(password).getPassword();
		//return password;
		}
	
	 @RequestMapping("/")
	    public ModelAndView home(Map<String, Object> model)
	    {
			ModelAndView mav= new ModelAndView ("index");
			return mav;
		}
	 
	    @RequestMapping(value = "/login", method = RequestMethod.GET)
		   public ModelAndView show() {
		      return new ModelAndView("login");
		   }
	    
	    
	    @RequestMapping(value = "/login", method = RequestMethod.POST)

		   public ModelAndView valid(Model model,@ModelAttribute("UserPojo")UserPojo userpojo,@ModelAttribute("userMail")String email,
				   @ModelAttribute("password")String password, HttpServletRequest req)

	{
	   	if((userRepo.findByPassword(password)!=null) && (userRepo.findByuserMail(email).getUserMail()!=null))
	    	{
	   		String userName=userRepo.findByuserMail(email).getUserName();
	   	 HttpSession session=req.getSession();
	   	session.setAttribute("userName", userName);
	    	return new ModelAndView("index");
	    	}
	    	else
	    	{
	    	model.addAttribute("mssg","Invalid Login Credentials!Try Again.");
	    	return new ModelAndView("login");
	    	}
	}
	    
	
	    @RequestMapping(value = "/register", method = RequestMethod.GET)
		   public ModelAndView showregister() {
		      return new ModelAndView("Registration");
		   }
	    
	    @RequestMapping(value = "/register", method = RequestMethod.POST)

		   public ModelAndView regvalid(Model model,@ModelAttribute("userName")String userName,@ModelAttribute("userMail")String userMail,
				   @ModelAttribute("phone")String phone,@ModelAttribute("password")String password,@ModelAttribute("confirmPassword")String confirmPassword,UserPojo user,BindingResult result,Map<String,Object> model1)
				   
		   {
	    
	    	if(!(password.equals(confirmPassword)))
	    	{
	    			model.addAttribute("msg","Confirm Password and original password do not match!!");
		    		return new ModelAndView("Registration");
	    			    		
	    	}
	    	else if(userRepo.findByPhone(phone)!=null || userRepo.findByuserMail(userMail)!=null)
    		{
    			 model.addAttribute("msg1","User with this Mail-ID or PhoneNumber already exists.Try another Mail-ID and Phone Number");
	    		 ModelAndView mav= new ModelAndView ("Registration");
	     		return mav;
    		}
	    	else
	    	{
	    		userRepo.create(userName,userMail,phone,password);
		    	return new ModelAndView("index"); 
	    	}
	    	
		   }
		   
	    
	}