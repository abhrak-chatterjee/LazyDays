package com.capgemini.lazydays.main;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
	public class LoginRegisterController 
	{
	/*@Autowired
	private UserServiceImplementation userService;*/
	 @RequestMapping("/")
	    public ModelAndView home(Map<String, Object> model)
	    {
			ModelAndView mav= new ModelAndView ("index");
			return mav;
		}
	    
	    @RequestMapping("/faq")
	    public ModelAndView faq(Map<String, Object> model){
	   		
	    	ModelAndView mav= new ModelAndView ("FAQs");
			return mav;
	   	}
	    @RequestMapping("/about")
	public ModelAndView about(Map<String, Object> model){
	   		
	    	ModelAndView mav= new ModelAndView ("about");
			return mav;
	   	}
	    @RequestMapping("/contact")
	public ModelAndView contact(Map<String, Object> model){
	   		
	    	ModelAndView mav= new ModelAndView ("contact");
			return mav;
	   	}
	    @RequestMapping(value = "/login", method = RequestMethod.GET)
		   public ModelAndView show() {
		      return new ModelAndView("login");
		   }
	    
	   
	    @RequestMapping(value = "/login", method = RequestMethod.POST)

		   public ModelAndView valid(Model model,@ModelAttribute("userMail")String userMail,
				   @ModelAttribute("password")String password, HttpServletRequest req)

	{
	    	   
	    	UserServiceImpl userService=new UserServiceImpl();  
	    	boolean x=false;
	    	String userName;
	        x=userService.isUserExist(userMail,password);
	        if(x==false)
	        {
	        	ModelAndView mav= new ModelAndView ("login");
	        	model.addAttribute("mssg","Invalid Login Credentials!Try Again.");
				return mav;
	  		 }
	        else
	        {
	        	ModelAndView mv = new ModelAndView(); 
	            HttpSession session=req.getSession();
   	        	userName=userService.findByUserName(userMail);	        
   	     
   	        	model.addAttribute("msg",userName);
   	        
   	        	 session.setAttribute("userName",userName);
                 System.out.println(session.getAttribute("userName"));
                 mv.setViewName("index");
                 return mv;

	        }
		   }
	    
	   /* 
	    @RequestMapping(value = "/login", method = RequestMethod.POST)

		   public ModelAndView valid(Model model,@ModelAttribute("userMail")String userMail,
				   @ModelAttribute("password")String password, HttpServletRequest req,UserPojo user,BindingResult result)

	{
	    		if(result.hasErrors())
				    {  	
				System.out.println("fhf");
				return new ModelAndView ("login");
				    }
	    	if(userService.findByUserMailAndPassword(userMail,password)!=null)
	    	{
	    		
	            HttpSession session=req.getSession();
	            String mail=userService.findByUserMailAndPassword(userMail, password).getUserMail();
	            String pass=userService.findByUserMailAndPassword(userMail, password).getPassword();
	            if(mail.equals(userMail) && pass.equals(password))
	            {
	            	ModelAndView mv = new ModelAndView("index");
	            	return mv;
	            	
	            }
	            else
	            {
	            	ModelAndView mav= new ModelAndView ("login");
		        	model.addAttribute("mssg","Invalid Login Credentials!Try Again.");
					return mav;
	            }
	    	}
			return new ModelAndView ("login");
	       

	        }
	    */
	    

	   
	    
	    
	    
	    @RequestMapping(value = "/register", method = RequestMethod.GET)
		   public ModelAndView showregister() {
		      return new ModelAndView("Registration");
		   }
	    
	    @RequestMapping(value = "/register", method = RequestMethod.POST)

		   public ModelAndView regvalid(Model model,@ModelAttribute("userName")String userName,@ModelAttribute("userMail")String userMail,
				   @ModelAttribute("phone")String phone,@ModelAttribute("password")String password,@ModelAttribute("confirmPassword")String confirmPassword,UserPojo user,BindingResult result,Map<String,Object> model1)
				   
		   {
	    	UserServiceImpl userService=new UserServiceImpl();
	    	if (result.hasErrors())
	    	{
	    		ModelAndView mav= new ModelAndView ("Registration");
	    		return mav;
	    		
	    	}
	    
	    	 if(!(confirmPassword.equals(password)))

			  {

			  model.addAttribute("msg","Confirm Password and original password do not match!!");

			  ModelAndView mav= new ModelAndView ("Registration");
	  		return mav;

			  }
	    	int x=0;
	    	  x=userService.save(userName,userMail,phone,password);
	    		
	    	 if(x==-1)
	    	 {
	    		 model.addAttribute("msg1","User with this Mail-ID or PhoneNumber already exists.Try another Mail-ID and Phone Number");
	    		 ModelAndView mav= new ModelAndView ("Registration");
	     		return mav;
	    	 }

	    	 ModelAndView mav= new ModelAndView ("index");
	 		return mav;
		   }
		   
	    
	}