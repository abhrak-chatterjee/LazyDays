package com.capgemini.lazydays.main;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

public class FlightServiceTest 
{
    FlightService flightService=new FlightService();
    @Test
    public void testFindBySource() 
    {
        String source="Kolkata";
        assertEquals(true, flightService.findBySource(source));
    }

    @Test
    public void testFindByDestination() 
    {
        String destination="Bangalore";
        assertEquals(true, flightService.findByDestination(destination));
    }


    @Test
    public void testFindByClass() 
    {
        String cType="Economy";
        String date="09/12/2018";
        int seats=5;
        Assert.assertEquals(49085,(int)flightService.findByClass(cType,seats,date));
    }
}