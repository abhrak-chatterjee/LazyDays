package com.capgemini.lazydays.main;





import java.sql.Connection;

import java.sql.Date;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.sql.Statement;

import java.util.ArrayList;

import java.util.List;

 

public class FlightDao {

               

                Connection connection = null;

                public void connectDB() throws ClassNotFoundException, SQLException

                {

                                Class.forName("oracle.jdbc.driver.OracleDriver");

                                connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "swagata", "swagata111");

               

                }             

               

               

               

                public boolean findBySource(String source)

                {

                                try

                    {

                                                connectDB();

                                                Statement statement = connection.createStatement();

                                                ResultSet resultSet = statement.executeQuery("SELECT source FROM FLIGHTLIST");

                        while (resultSet.next())

                        {

                            if((source.equals(resultSet.getString("source"))) )

                            {

                                return true;

                            } 

 

                        }

                        return false;                      

                    }

                                catch(Exception exception)

                    {

                        System.out.println("Error!!");

 

                    }

                                return false;

                }

               

               

               

                public boolean findByDestination(String destination)

                {

                try

    {

                                connectDB();

                                Statement statement = connection.createStatement();

                                ResultSet resultSet = statement.executeQuery("SELECT destination FROM FLIGHTLIST");

        while (resultSet.next())

        {

            if((destination.equals(resultSet.getString("destination"))) )

            {

                return true;

            } 

 

        }

        return false;                      

    }

                catch(Exception exception)

    {

        System.out.println("Error!!");

 

    }

                return false;

                }

               

               

               

                public double findByClass(String classType,int noOfSeats,String journeyDate)

                {

                                try

                    {

                                                connectDB();

                                                Statement statement = connection.createStatement();

                                                if(classType.equalsIgnoreCase("Economy"))

                                                {

                                                                ResultSet resultSet = statement.executeQuery("SELECT economySeats,economyFare FROM FLIGHTLIST where journeyDate='"+journeyDate+"'");

                                                                while(resultSet.next())

                                                                {

                                                                                if(noOfSeats<=(resultSet.getInt("economySeats")))

                                                                                                return noOfSeats*((resultSet.getDouble("economyFare")));

                                                                }

                                                }

                                                else if(classType.equalsIgnoreCase("Business"))

                                                {

                                                                ResultSet resultSet = statement.executeQuery("SELECT businessSeats,businessFare FROM FLIGHTLIST where journeyDate='"+journeyDate+"'");

                                                                while(resultSet.next())

                                                                {

                                                                                if(noOfSeats<=(resultSet.getInt("businessSeats")))

                                                                                                return noOfSeats*((resultSet.getDouble("businessFare")));

                                                                }

                                                }

                                               

                    }

                                catch(Exception exception)

                    {

                        System.out.println("Error!!");

                    }

                                return 0;

                }

                               

                public List<FlightPojo> availableFlights(String source,String destination,String journeyDate,String classType,int seats)

                {

                                List<FlightPojo> flights=new ArrayList<FlightPojo>();

                                try

                    {

                                                connectDB();

                                                Statement statement = connection.createStatement();

                                                ResultSet resultSet = statement.executeQuery("SELECT flightID FROM FLIGHTLIST");

                                                while (resultSet.next())

                         {

                                 boolean isSource=findBySource(source);

                                 boolean isDestination=findByDestination(destination);

                                 double fare=findByClass(classType,seats,journeyDate);

                                 if(isSource==true && isDestination==true && fare>0)

                                 {

                                                 int id=resultSet.getInt("flightID");

                                                 ResultSet resultSet1 = statement.executeQuery("SELECT company,arrivalTime,departureTime FROM FLIGHTLIST where flightID='"+id+"'");

                                                 while(resultSet1.next())

                                                 {

                                                                 String company=resultSet1.getString("company");

                                                                 String at=resultSet1.getString("arrivalTime");

                                                                 String dt=resultSet1.getString("departureTime");

                                                                 FlightPojo ob=new FlightPojo(company,at,dt,fare);

                                                                 flights.add(ob);

                                                 }                              

                                 }

                          }

                    }

                                catch(Exception exception)

                    {

                        System.out.println("Error!!");

                    }

                                return flights;

                }             

}

 

               

               

               

               

 

