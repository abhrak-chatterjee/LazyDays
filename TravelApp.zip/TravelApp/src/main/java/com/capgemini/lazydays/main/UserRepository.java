package com.capgemini.lazydays.main;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.stereotype.Repository;
@Repository
//@NoRepositoryBean
public interface UserRepository extends CrudRepository<UserPojo,String> 
{
public UserPojo findByUserMailAndPassword(String userMail,String password);

public UserPojo getByUserId(String userId);
}
