package com.capgemini.lazydays.main;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="usermmt")
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class UserPojo
{
	@Column(name="userId")
	 @Id
	String userId;
	@Column(name="userName")
	String userName;
	@Column(name="userMail")
	String userMail;
	@Column(name="phone")
	String phone;
	@Column(name="password")
	String password;
	public UserPojo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserPojo(String userId, String userName, String userMail, String phone, String password) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userMail = userMail;
		this.phone = phone;
		this.password = password;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserMail() {
		return userMail;
	}
	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "UserPojo [userId=" + userId + ", userName=" + userName + ", userMail=" + userMail + ", phone=" + phone
				+ ", password=" + password + "]";
	}
	
}
