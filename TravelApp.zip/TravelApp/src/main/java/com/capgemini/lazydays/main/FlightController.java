package com.capgemini.lazydays.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class FlightController 
{
    @RequestMapping(value = "/Flight", method = RequestMethod.GET)
    public ModelAndView show() {
    return new ModelAndView("Flight");
}
    
    
    @RequestMapping(value = "/Flight", method = RequestMethod.POST)

   public ModelAndView valid(Model model,@ModelAttribute("source")String source,
   @ModelAttribute("destination")String destination,@ModelAttribute("departDate")String departDate,
   @ModelAttribute("returnDate")String returnDate,
   @ModelAttribute("passengerNo")int passengerNo,@ModelAttribute("flightclass")String fclass,FlightPojo flight,BindingResult result,Map<String,Object> model1)
   

    {
    	FlightDao ob=new FlightDao();
    	if (result.hasErrors())
    	{
		    ModelAndView mav= new ModelAndView ("Flight");
		    System.out.println(passengerNo);
		    System.out.println("Class:"+fclass);
		    System.out.println("Date:"+departDate+returnDate);
		    System.out.println(source+destination);
		    List<FlightPojo> flist=new ArrayList<FlightPojo>();
            flist=ob.availableFlights(source,destination,departDate,fclass,passengerNo);
            System.out.println(flist.toString());
            model.addAttribute("msg",flist);
		    return mav;
		    
    }
    return new ModelAndView("Flight");
       
    
   }
    
    
    @RequestMapping(value = "/FlightBook", method = RequestMethod.POST)

   public ModelAndView valid(Model model,
		   @ModelAttribute("passengerNo")int passengerNo,
          FlightPojo flight,BindingResult result,Map<String,Object> model1)
   

  {
  if (result.hasErrors())
  {
  ModelAndView mav= new ModelAndView ("FlightBook");
 model.addAttribute("msg",passengerNo);
  return mav;
  
  }
  
  return new ModelAndView("FlightBook");
     
  
   }
 
    
    
    
    
}
