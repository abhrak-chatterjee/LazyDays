/*package com.capgemini.lazydays.main;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean
    public UserServiceImplementation userRepository() {
        return new UserServiceImplementation();
    }
}*/