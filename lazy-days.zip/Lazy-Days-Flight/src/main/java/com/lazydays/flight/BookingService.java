package com.lazydays.flight;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class BookingService{
	
	
	 @Autowired
     private BookingRepository repo;
	
	public BookingPojo create(String userName, String userMail, String company, String source, String destination,
			String arrivalTime, String departureTime, double fare, int seats) 
	  {

	      return repo.save(new BookingPojo(userName,userMail,company,source,destination,arrivalTime,departureTime,fare,seats));   

	}
}
