package com.capgemini.lazyDays;


import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;


@RestController

	public class LoginRegisterController 
	{
		@Autowired
		private UserService userRepo;
	
	    @RequestMapping(value = "/email/{userMail}", method = RequestMethod.GET)
	    public UserPojo getEmailId(@PathVariable String userMail)
	    {
	    	return userRepo.findByuserMail(userMail);
	    }
	    
	    
	    @RequestMapping(value = "/phone/{phone}", method = RequestMethod.GET)
	    public UserPojo getPhone(@PathVariable String phone)
	    {
	    	return userRepo.findByPhone(phone);
	    }
	    
	    
	    @RequestMapping(value = "/register", method = RequestMethod.POST)
		   public void regvalid(Model model,@RequestBody UserPojo user,BindingResult result,Map<String,Object> model1)				   
		   {
	    		userRepo.create(user.userName,user.userMail,user.phone,user.password);		    	
	       }
	}