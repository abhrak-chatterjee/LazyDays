package com.capgemini.lazyDays;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController

	public class LoginRegisterController 
	{
		@Autowired
		private UserService userRepo;
	
	    @RequestMapping(value = "/email/{userMail}", method = RequestMethod.GET)
	    public UserPojo getEmailId(@PathVariable String userMail)
	    {
	    	return userRepo.findByuserMail(userMail);
	    }
	    
	    
	    @RequestMapping(value = "/phone/{phone}", method = RequestMethod.GET)
	    public UserPojo getPhone(@PathVariable String phone)
	    {
	    	return userRepo.findByPhone(phone);
	    }
	    
	    
	    @RequestMapping(value = "/register", method = RequestMethod.POST)
		   public void regvalid(Model model,@RequestBody UserPojo user,BindingResult result,Map<String,Object> model1)				   
		   {
	    		userRepo.create(user.userName,user.userMail,user.phone,user.password);		    	
	       }
	}