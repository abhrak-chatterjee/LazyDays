package com.capgemini;

public class FlightPojo
{

public String company;
public String source;
public String destination;
public String departureTime;
public String arrivalTime;
public String date;
public int economySeats;
public int businessSeats;
public double economyFare;
public double businessFare;
public double fare;
public int flightID;

public String flightClass;
public int passengers;
public String departureDate;
public String returnDate;

public FlightPojo(String company, String source, String destination, String departureTime, String arrivalTime,
		String date, int economySeats, int businessSeats, double economyFare, double businessFare, double fare,
		int flightID) {
	super();
	this.company = company;
	this.source = source;
	this.destination = destination;
	this.departureTime = departureTime;
	this.arrivalTime = arrivalTime;
	this.date = date;
	this.economySeats = economySeats;
	this.businessSeats = businessSeats;
	this.economyFare = economyFare;
	this.businessFare = businessFare;
	this.fare = fare;
	this.flightID = flightID;
}

public FlightPojo(int id,String company,String departureTime, String arrivalTime,double fare) 
{

super();
this.flightID=id;
this.company = company;

this.departureTime = departureTime;

this.arrivalTime = arrivalTime;

this.fare = fare;

}


public FlightPojo(String company, String source, String destination, String departureTime, String arrivalTime,
		String date, int economySeats, int businessSeats, double economyFare, double businessFare, double fare,
		int flightID, String flightClass, int passengers, String departureDate, String returnDate) {
	super();
	this.company = company;
	this.source = source;
	this.destination = destination;
	this.departureTime = departureTime;
	this.arrivalTime = arrivalTime;
	this.date = date;
	this.economySeats = economySeats;
	this.businessSeats = businessSeats;
	this.economyFare = economyFare;
	this.businessFare = businessFare;
	this.fare = fare;
	this.flightID = flightID;
	this.flightClass = flightClass;
	this.passengers = passengers;
	this.departureDate = departureDate;
	this.returnDate = returnDate;
}

public FlightPojo(String source, String destination, String departureTime, String arrivalTime,
		int passengers, String flightClass) {
	super();
	this.source = source;
	this.destination = destination;
	this.departureTime = departureTime;
	this.arrivalTime = arrivalTime;
	this.flightClass = flightClass;
	this.passengers = passengers;
}

public String getCompany() {
	return company;
}

public void setCompany(String company) {
	this.company = company;
}

public String getSource() {
	return source;
}

public void setSource(String source) {
	this.source = source;
}

public String getDestination() {
	return destination;
}

public void setDestination(String destination) {
	this.destination = destination;
}

public String getDepartureTime() {
	return departureTime;
}

public void setDepartureTime(String departureTime) {
	this.departureTime = departureTime;
}

public String getArrivalTime() {
	return arrivalTime;
}

public void setArrivalTime(String arrivalTime) {
	this.arrivalTime = arrivalTime;
}

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public int getEconomySeats() {
	return economySeats;
}

public void setEconomySeats(int economySeats) {
	this.economySeats = economySeats;
}

public int getBusinessSeats() {
	return businessSeats;
}

public void setBusinessSeats(int businessSeats) {
	this.businessSeats = businessSeats;
}

public double getEconomyFare() {
	return economyFare;
}

public void setEconomyFare(double economyFare) {
	this.economyFare = economyFare;
}

public double getBusinessFare() {
	return businessFare;
}

public void setBusinessFare(double businessFare) {
	this.businessFare = businessFare;
}

public double getFare() {
	return fare;
}

public void setFare(double fare) {
	this.fare = fare;
}

public int getFlightID() {
	return flightID;
}

public void setFlightID(int flightID) {
	this.flightID = flightID;
}

public String getFlightClass() {
	return flightClass;
}

public void setFlightClass(String flightClass) {
	this.flightClass = flightClass;
}

public int getPassengers() {
	return passengers;
}

public void setPassengers(int passengers) {
	this.passengers = passengers;
}

public String getDepartureDate() {
	return departureDate;
}

public void setDepartureDate(String departureDate) {
	this.departureDate = departureDate;
}

public String getreturnDate() {
	return returnDate;
}

public void setreturnDate(String returnDate) {
	this.returnDate = returnDate;
}

@Override
public String toString() {
	return "[company=" + company + ", departureTime=" + departureTime + ", arrivalTime=" + arrivalTime
			+ ", fare=" + fare + "]";
}

}