package com.capgemini;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;


@RestController

	public class UI_Controller 
	{
	 	@RequestMapping("/")
	    public ModelAndView home(Map<String, Object> model)
	    {
			ModelAndView mav= new ModelAndView ("index");
			return mav;
		}	 
	    @RequestMapping(value = "/login", method = RequestMethod.GET)
		public ModelAndView show() 
	    {
	        return new ModelAndView("login");
	        
		}	    
	    @RequestMapping(value = "/register", method = RequestMethod.GET)
	   public ModelAndView showregister() 
    	{
	       return new ModelAndView("register");
	    }
	    @RequestMapping(value = "/Flight", method = RequestMethod.GET)
		   public ModelAndView flight() 
	       {
		      return new ModelAndView("Flight");
		   } 
	
	    @RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView createEmployee(Model model,@ModelAttribute("userName")String userName,@ModelAttribute("userMail")String userMail,
			   @ModelAttribute("phone")String phone,@ModelAttribute("password")String password,@ModelAttribute("confirmPassword")String confirmPassword)
	{
	    	RestTemplate restTemplate = new RestTemplate();
	    	
	    	if(!(password.equals(confirmPassword)))
	    	{
	    			model.addAttribute("msg","Confirm Password and original password do not match!!");
		    		return new ModelAndView("register");	    			    		
	    	}   	    	
	    	else
	    	{
	    		final String mail = "http://localhost:9085/email/"+userMail;
	    		final String ph = "http://localhost:9085/phone/"+phone;
	    		UserPojo res1 = restTemplate.getForObject(mail,UserPojo.class);
	    		UserPojo res2 = restTemplate.getForObject(ph,UserPojo.class);
	    		if(res1!=null || res2!=null)
	    		{
	    			 model.addAttribute("msg1","User with this Mail-ID or PhoneNumber already exists.Try another Mail-ID and Phone Number");
	    			 return new ModelAndView("register");
	    		}
	    		else
	    		{
	    			final String uri = "http://localhost:9085/register";	    			 
	    		    UserPojo newUser = new UserPojo(userName,userMail,phone,password,confirmPassword);    		    
	    		    UserPojo result = restTemplate.postForObject( uri, newUser, UserPojo.class);
	    		    return new ModelAndView("index");
	    		}
	    			
	    	}
	}
	    
	    @RequestMapping(value = "/login", method = RequestMethod.POST)
		public ModelAndView loginEmployee(Model model,@ModelAttribute("userMail")String userMail,@ModelAttribute("password")String password,HttpServletRequest req)
		{
		    	RestTemplate restTemplate = new RestTemplate();
		    	final String mail = "http://localhost:9085/email/"+userMail;
		    	UserPojo res1 = restTemplate.getForObject(mail,UserPojo.class);
		    		
		    		if(res1!=null)
		    		{
		    			model.addAttribute("mssg",res1.getPassword());
		    			if(password.equals(res1.getPassword()))
		    			{
		    				System.out.println(res1.getPassword());
		    				String userName=res1.getUserName();
					   		HttpSession session=req.getSession();
					   		session.setAttribute("userName", userName);
					    	return new ModelAndView("index");
		    			}
		    			else
				    	{
					    	model.addAttribute("mssg","Invalid Password!Try Again.");
					    	return new ModelAndView("login");
				    	}
		    		}
		    		else
		    		{
		    			model.addAttribute("mssg","Invalid User Mail!Try Again.");
				    	return new ModelAndView("login");
		    		}
		}
	    
	    @RequestMapping(value = "/Flight", method = RequestMethod.POST)

		   public ModelAndView journeyflight(Model model,@ModelAttribute("source")String source,
					   @ModelAttribute("destination")String destination,@ModelAttribute("departDate")String departDate,
					   @ModelAttribute("returnDate")String returnDate,
					   @ModelAttribute("passengerNo")int passengerNo,@ModelAttribute("flightclass")String fclass,
					   BindingResult result,Map<String,Object> model1)
		    {	
	    		RestTemplate restTemplate = new RestTemplate();
	    		final String uri = "http://localhost:9099/Flight";	    			 
    		    FlightPojo newFlight = new FlightPojo(source,destination,departDate,returnDate,passengerNo,fclass);    		    
    		    FlightPojo flightResult = restTemplate.postForObject( uri, newFlight, FlightPojo.class);
    		    return new ModelAndView("index");	    	
		    }
	    
	    /*@RequestMapping(value="/booking", method = RequestMethod.POST)
	    public ModelAndView book(Model model,@ModelAttribute("flightId")int id)
	    {
	    	RestTemplate restTemplate = new RestTemplate();
	    	String company="",departureTime="",arrivalTime="",userName="",userMail="";
	    	double fare=0.0;
	    	for (int counter = 0; counter < flightList.size(); counter++) 
	    	{ 
	    		if((counter+1)==id)
	    		{
	    			 userName="Swagata";
	    			 userMail="swag@gmail.com";
	    			 fare=flightList.get(counter).getFare();
	    			 company=flightList.get(counter).getCompany();
	    			 departureTime =flightList.get(counter).getDepartureTime();
	    			arrivalTime=flightList.get(counter).getArrivalTime();
	    				
	    			model.addAttribute("cmp",flightList.get(counter).getCompany());
	    			model.addAttribute("src",source1);
	    			model.addAttribute("dest",destination1);
	    			model.addAttribute("dept",flightList.get(counter).getDepartureTime());
	    			model.addAttribute("arriv",flightList.get(counter).getArrivalTime());
	            
	        }  }
	    	
			bookObj.create(userName, userMail, company, source1, destination1, arrivalTime, departureTime, fare, seats1);
			return new ModelAndView("booking");
		}*/
}