package com.lazydays.flight;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="flightbooking")
public class BookingPojo {
	
	private String userName;
	private String userMail;
	private String company;
	private String source;
	private String destination;
	private String arrivalTime;
	private String departureTime;
	private double fare;
	private int seats;
	
	public BookingPojo(String userName, String userMail, String company, String source, String destination,
			String arrivalTime, String departureTime, double fare, int seats) {
		super();
		this.userName = userName;
		this.userMail = userMail;
		this.company = company;
		this.source = source;
		this.destination = destination;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.fare = fare;
		this.seats = seats;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserMail() {
		return userMail;
	}
	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}

}
