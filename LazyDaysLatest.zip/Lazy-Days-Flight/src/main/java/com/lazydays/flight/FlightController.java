package com.lazydays.flight;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;



@RestController

	public class FlightController 
	{
	String source1="";
	String destination1="";
	
	int seats1=0;
	ArrayList<FlightPojo> flightList=new ArrayList<FlightPojo>();
	
	@Autowired
	private BookingService bookObj;
	
	@RequestMapping("/")
	    public ModelAndView home(Map<String, Object> model)
	    {
			ModelAndView mav= new ModelAndView ("index");
			return mav;
		}
	
	    @RequestMapping(value = "/Flight", method = RequestMethod.GET)
		   public ModelAndView show() {
		      return new ModelAndView("Flight");
		   }
	    
	    
	    /*@RequestMapping(value = "/Flight", method = RequestMethod.POST)

	   public ModelAndView journeyflight(Model model,@ModelAttribute("source")String source,
				   @ModelAttribute("destination")String destination,@ModelAttribute("departDate")String departDate,
				   @ModelAttribute("returnDate")String returnDate,
				   @ModelAttribute("passengerNo")int passengerNo,@ModelAttribute("flightclass")String fclass,FlightPojo flight,BindingResult result,Map<String,Object> model1)
	    {	
	    	
	    	FetchAPI ob=new FetchAPI();
	    	
	    	ArrayList<FlightPojo> flightListReturn=new ArrayList<FlightPojo>();
	    	try {
	    		String y=departDate.substring(6,departDate.length());
	            String d=departDate.substring(3,5);
	            String m=departDate.substring(0,2);
	            String deptDate=y+m+d;
	            flightList=ob.fetch(source, destination, deptDate, fclass, passengerNo);
	            
	            if(returnDate.length()>6)
	            {
	            	y=returnDate.substring(6,returnDate.length());
		            d=returnDate.substring(3,5);
		            m=returnDate.substring(0,2);
		            String retDate=y+m+d;
					flightListReturn=ob.fetch(destination, source, retDate, fclass, passengerNo);
	            }
	            
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	source1=source;
	    	destination1=destination;
	    	seats1=passengerNo;
	    
	    	
	    	 model.addAttribute("ret",returnDate);
		    	model.addAttribute("src",source);
	            model.addAttribute("dest",destination);
	            model.addAttribute("msg",flightList);
	            model.addAttribute("msg1",flightListReturn);
	            return new ModelAndView("Flight");
	    	
	    	
	    }*/
	    
	    /*@RequestMapping(value = "/{source}/{destination}/{departDate}/{returnDate}/{passengerNo}/{flightclass}", method = RequestMethod.GET)
	    public FlightPojo getDetails(Model model, @PathVariable(value="source") String source,@PathVariable(value="destination") String destination,
	    @PathVariable(value="departDate") String departDate,@PathVariable(value="returnDate") String returnDate,@PathVariable(value="passengerNo") int passengerNo,
	    @PathVariable(value="flightClass") String fclass)*/
	    
	    @RequestMapping(value = "/Flight", method = RequestMethod.POST)
	    public ModelAndView getDetails(Model model,@RequestBody FlightPojo flight,BindingResult result,Map<String,Object> model1)
	    {
	    	FetchAPI ob=new FetchAPI();
	    	
	    	ArrayList<FlightPojo> flightListReturn=new ArrayList<FlightPojo>();
	    	try {
	    		String y=flight.departureDate.substring(6,flight.departureDate.length());
	            String d=flight.departureDate.substring(3,5);
	            String m=flight.departureDate.substring(0,2);
	            String deptDate=y+m+d;
	            flightList=ob.fetch(flight.source, flight.destination, deptDate, flight.flightClass, flight.passengers);
	            
	            if(flight.returnDate.length()>6)
	            {
	            	y=flight.returnDate.substring(6,flight.returnDate.length());
		            d=flight.returnDate.substring(3,5);
		            m=flight.returnDate.substring(0,2);
		            String retDate=y+m+d;
					flightListReturn=ob.fetch(flight.destination, flight.source, retDate, flight.flightClass, flight.passengers);
	            }
	            
			} catch (IOException e) {
				
				e.printStackTrace();
			}
	    	source1=flight.source;
	    	destination1=flight.destination;
	    	seats1=flight.passengers;
	    
	    	
	    	 	model.addAttribute("ret",flight.returnDate);
		    	model.addAttribute("src",flight.source);
	            model.addAttribute("dest",flight.destination);
	            model.addAttribute("msg",flightList);
	            model.addAttribute("msg1",flightListReturn);
	            return new ModelAndView("Flight");
	    }
	     
	    
	    /*@RequestMapping("/booking")
	    public ModelAndView book(Model model,@ModelAttribute("flightId")int id)
	    {
	    	
	    	String company="",departureTime="",arrivalTime="",userName="",userMail="";
	    	double fare=0.0;
	    	for (int counter = 0; counter < flightList.size(); counter++) 
	    	{ 
	    		if((counter+1)==id)
	    		{
	    			 userName="Abhrak";
	    			 userMail="abhrak@gmail.com";
	    			 fare=flightList.get(counter).getFare();
	    			 company=flightList.get(counter).getCompany();
	    			 departureTime =flightList.get(counter).getDepartureTime();
	    			arrivalTime=flightList.get(counter).getArrivalTime();
	    				
	    			model.addAttribute("cmp",flightList.get(counter).getCompany());
	    			model.addAttribute("src",source1);
	    			model.addAttribute("dest",destination1);
	    			model.addAttribute("dept",flightList.get(counter).getDepartureTime());
	    			model.addAttribute("arriv",flightList.get(counter).getArrivalTime());
	            
	        }  }
	    	
			bookObj.create(userName, userMail, company, source1, destination1, arrivalTime, departureTime, fare, seats1);
			return new ModelAndView("booking");
		}*/
	    	
}

	    	
	