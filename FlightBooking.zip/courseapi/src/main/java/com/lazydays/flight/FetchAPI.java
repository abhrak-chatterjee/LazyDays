package com.lazydays.flight;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;




public class FetchAPI {
                
                  private static String readAll(Reader rd) throws IOException {
                                    StringBuilder sb = new StringBuilder();
                                    int cp;
                                    while ((cp = rd.read()) != -1) {
                                      sb.append((char) cp);
                                    }
                                    return sb.toString();
                                  }

                                  public ArrayList<FlightPojo> readJsonFromUrl(String url) throws IOException, JSONException {
                                    InputStream is = new URL(url).openStream();
                                    try {
                                      BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
                                      String jsonText = readAll(rd);
                                      ArrayList<FlightPojo> flights=new ArrayList<FlightPojo>();
                                      
                                      JSONObject json = new JSONObject(jsonText);
                                      JSONObject data = json.getJSONObject( "data" );
                                      JSONArray onward = data.getJSONArray("onwardflights");
                                      for(int i=0;i<25;i++)
                                      {
                                    	  double fare=Double.parseDouble(onward.getJSONObject(i).getJSONObject("fare").getString("totalfare"));
                                    	  String arrivalTime=onward.getJSONObject(i).getString("arrtime");
                                    	  String departureTime=onward.getJSONObject(i).getString("deptime");
                                    	  String company=onward.getJSONObject(i).getString("airline");
                                       	  //System.out.println(i+" = "+arrivalTime+" "+company+" "+departureTime);
                                       	  int id=i+1;
                                       	  flights.add(new FlightPojo(id,company,departureTime,arrivalTime,fare));
                                       	  
                                    	  
                                      }                                     
                                     return flights;
                                    } finally {
                                      is.close();
                                    }
                                  }
                                  
                                  public ArrayList<FlightPojo> fetch(String source,String destination,String departDate,String fclass,int seats) throws IOException {
                                                  ArrayList<FlightPojo> list=new ArrayList<FlightPojo>();
                                                                     
                                                                  try{
                                                                	  
                                                     String url="https://developer.goibibo.com/api/search/?app_id=6a912693&app_key=89d6c6558118c949c68762e43dbf27af&source="+source+"&destination="+destination+"&dateofdeparture="+departDate+"&seatingclass="+fclass+"&adults="+seats+"&children=0&infants=0&counter=100";    
                                                     list = readJsonFromUrl(url);
                                                     //System.out.println("dATA RECEIVED SUCESSFULLY");
                                                                  }
                                                                  catch(Exception e)
                                                                  {
                                                                                  e.printStackTrace();
                                                                  }
                                                                  return list;

                                  }
}


